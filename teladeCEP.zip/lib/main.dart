import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Consulta de CEP',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: CepConsultaScreen(),
    );
  }
}

class CepConsultaScreen extends StatefulWidget {
  @override
  _CepConsultaScreenState createState() => _CepConsultaScreenState();
}

class _CepConsultaScreenState extends State<CepConsultaScreen> {
  final TextEditingController _cepController = TextEditingController();
  String? _resultado;

  Future<void> _consultarCep() async {
    final String cep = _cepController.text;
    final response =
        await http.get(Uri.parse('https://viacep.com.br/ws/$cep/json/'));

    if (response.statusCode == 200) {
      final Map<String, dynamic> data = json.decode(response.body);
      if (data['erro'] != null) {
        setState(() {
          _resultado = 'CEP não encontrado!';
        });
      } else {
        setState(() {
          _resultado =
              'Endereço: ${data['logradouro']}, ${data['bairro']}, ${data['localidade']} - ${data['uf']}';
        });
      }
    } else {
      setState(() {
        _resultado = 'Erro ao consultar CEP!';
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Consulta de CEP'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _cepController,
              decoration: InputDecoration(
                labelText: 'Digite o CEP',
                border: OutlineInputBorder(),
              ),
              keyboardType: TextInputType.number,
            ),
            SizedBox(height: 10),
            ElevatedButton(
              onPressed: _consultarCep,
              child: Text('Consultar'),
            ),
            SizedBox(height: 20),
            if (_resultado != null)
              Text(
                _resultado!,
                style: TextStyle(fontSize: 16),
                textAlign: TextAlign.center,
              ),
          ],
        ),
      ),
    );
  }
}
